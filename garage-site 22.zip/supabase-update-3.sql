-- Garage 1.6.0: друзі, чат, закриті розділи профілю, пости «Тільки друзі».
-- Вставте весь цей текст у Supabase -> SQL Editor і натисніть Run.
-- Можна запускати повторно: нічого не зламається. Спершу мають бути виконані update-1 і update-2.

-- 1) Нік у профілі (його ставить сам застосунок із «Імені» в Профілі)
alter table public.profiles add column if not exists display_name text;
alter table public.profiles drop constraint if exists profiles_display_name_len;
alter table public.profiles add constraint profiles_display_name_len check (display_name is null or char_length(display_name) <= 40);

create or replace function public.set_my_name(n text) returns void
language sql security definer set search_path = public as $$
  update public.profiles set display_name = left(trim(coalesce(n, '')), 40) where user_id = auth.uid();
$$;

-- 2) Друзі: запит -> прийняття
create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  requester uuid not null default auth.uid() references auth.users(id) on delete cascade,
  addressee uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted')),
  created_at timestamptz not null default now(),
  check (requester <> addressee)
);
create unique index if not exists friendships_pair_idx
  on public.friendships (least(requester, addressee), greatest(requester, addressee));
alter table public.friendships enable row level security;

drop policy if exists "friendships read" on public.friendships;
create policy "friendships read" on public.friendships for select to authenticated
  using (auth.uid() in (requester, addressee));
drop policy if exists "friendships insert" on public.friendships;
create policy "friendships insert" on public.friendships for insert to authenticated
  with check (requester = auth.uid() and status = 'pending');
drop policy if exists "friendships accept" on public.friendships;
create policy "friendships accept" on public.friendships for update to authenticated
  using (addressee = auth.uid()) with check (addressee = auth.uid());
drop policy if exists "friendships delete" on public.friendships;
create policy "friendships delete" on public.friendships for delete to authenticated
  using (auth.uid() in (requester, addressee));
-- змінити можна тільки статус (щоб ніхто не підмінив учасників)
revoke update on public.friendships from authenticated;
grant update (status) on public.friendships to authenticated;

create or replace function public.are_friends(a uuid, b uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.friendships f
    where f.status = 'accepted'
      and ((f.requester = a and f.addressee = b) or (f.requester = b and f.addressee = a))
  )
$$;

-- 3) Пошук людей за ID (GAR-0000002 або просто 2) або за ніком
create or replace function public.find_profiles(q text)
returns table (user_id uuid, public_no bigint, display_name text)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare
  s text := trim(coalesce(q, ''));
  num bigint := null;
begin
  if char_length(s) < 1 then return; end if;
  if s ~* '^(gar-?)?[0-9]{1,12}$' then
    num := regexp_replace(s, '[^0-9]', '', 'g')::bigint;
  end if;
  s := replace(replace(s, '%', ''), '_', '');
  return query
    select p.user_id, p.public_no, p.display_name
    from public.profiles p
    where p.user_id <> auth.uid()
      and ((num is not null and p.public_no = num)
           or (char_length(s) >= 2 and p.display_name ilike ('%' || s || '%')))
    order by p.public_no
    limit 10;
end $$;

-- Мої друзі й запити (з іменами)
create or replace function public.my_friends()
returns table (friendship_id uuid, other_id uuid, status text, i_sent boolean,
               public_no bigint, display_name text, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select f.id,
         case when f.requester = auth.uid() then f.addressee else f.requester end,
         f.status,
         f.requester = auth.uid(),
         p.public_no,
         p.display_name,
         f.created_at
  from public.friendships f
  join public.profiles p
    on p.user_id = case when f.requester = auth.uid() then f.addressee else f.requester end
  where auth.uid() in (f.requester, f.addressee)
$$;

-- 4) Профіль для друзів (власник сам вирішує, які розділи показувати: у базу потрапляють тільки відкриті)
create table if not exists public.profile_shares (
  user_id uuid primary key default auth.uid() references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  hidden text[] not null default '{}',
  updated_at timestamptz not null default now()
);
alter table public.profile_shares enable row level security;
drop policy if exists "shares read" on public.profile_shares;
create policy "shares read" on public.profile_shares for select to authenticated
  using (user_id = auth.uid() or public.are_friends(auth.uid(), user_id));
drop policy if exists "shares insert own" on public.profile_shares;
create policy "shares insert own" on public.profile_shares for insert to authenticated
  with check (user_id = auth.uid());
drop policy if exists "shares update own" on public.profile_shares;
create policy "shares update own" on public.profile_shares for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "shares delete own" on public.profile_shares;
create policy "shares delete own" on public.profile_shares for delete to authenticated
  using (user_id = auth.uid());

-- 5) Чат (тільки між друзями)
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender uuid not null default auth.uid() references auth.users(id) on delete cascade,
  recipient uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now(),
  read_at timestamptz
);
create index if not exists messages_recipient_idx on public.messages (recipient, created_at desc);
create index if not exists messages_sender_idx on public.messages (sender, created_at desc);
alter table public.messages enable row level security;
drop policy if exists "messages read" on public.messages;
create policy "messages read" on public.messages for select to authenticated
  using (auth.uid() in (sender, recipient));
drop policy if exists "messages insert" on public.messages;
create policy "messages insert" on public.messages for insert to authenticated
  with check (sender = auth.uid() and public.are_friends(sender, recipient));
drop policy if exists "messages mark read" on public.messages;
create policy "messages mark read" on public.messages for update to authenticated
  using (recipient = auth.uid()) with check (recipient = auth.uid());
drop policy if exists "messages delete own" on public.messages;
create policy "messages delete own" on public.messages for delete to authenticated
  using (sender = auth.uid());
revoke update on public.messages from authenticated;
grant update (read_at) on public.messages to authenticated;

-- 6) Стрічка: видимість «Тільки друзі»
alter table public.posts drop constraint if exists posts_visibility_check;
alter table public.posts add constraint posts_visibility_check
  check (visibility in ('public','private','friends'));

drop policy if exists "posts read" on public.posts;
create policy "posts read" on public.posts for select to authenticated
  using (
    (visibility = 'public' and not hidden)
    or user_id = auth.uid()
    or public.is_admin()
    or (visibility = 'friends' and not hidden and public.are_friends(auth.uid(), user_id))
  );

drop policy if exists "feed read" on storage.objects;
create policy "feed read" on storage.objects for select to authenticated
  using (bucket_id = 'feed' and (
    (storage.foldername(name))[1] = auth.uid()::text
    or public.is_admin()
    or exists (select 1 from public.posts p where p.photo_path = name and p.visibility = 'public' and not p.hidden)
    or exists (select 1 from public.posts p where p.photo_path = name and p.visibility = 'friends' and not p.hidden
               and public.are_friends(auth.uid(), p.user_id))
  ));

-- Перевірка: має показати 3 таблиці зі словом true в колонці rowsecurity.
select tablename, rowsecurity from pg_tables
where schemaname = 'public' and tablename in ('friendships','messages','profile_shares') order by tablename;
