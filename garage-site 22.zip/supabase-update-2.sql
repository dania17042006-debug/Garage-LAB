-- Garage: стрічка (пости з фото, лайки, коментарі, скарги).
-- Вставте весь цей текст у Supabase -> SQL Editor і натисніть Run.
-- Можна запускати повторно: нічого не зламається.

-- 0) Хто адмін (акаунт №1 = ви)
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where user_id = auth.uid() and public_no = 1)
$$;

-- 1) Пости
create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  author_name text not null default '' check (char_length(author_name) <= 40),
  author_no bigint,
  caption text not null default '' check (char_length(caption) <= 300),
  photo_path text not null,
  visibility text not null default 'public' check (visibility in ('public','private')),
  hidden boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists posts_created_idx on public.posts (created_at desc);
alter table public.posts enable row level security;

-- 2) Лайки
create table if not exists public.likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);
alter table public.likes enable row level security;

-- 3) Коментарі
create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  author_name text not null default '' check (char_length(author_name) <= 40),
  author_no bigint,
  body text not null check (char_length(body) between 1 and 300),
  created_at timestamptz not null default now()
);
create index if not exists comments_post_idx on public.comments (post_id, created_at);
alter table public.comments enable row level security;

-- 4) Скарги (читаєте ви в Table Editor -> reports). 3 скарги = пост ховається автоматично.
create table if not exists public.reports (
  id bigint generated always as identity primary key,
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  reason text not null default '' check (char_length(reason) <= 200),
  created_at timestamptz not null default now(),
  unique (post_id, user_id)
);
alter table public.reports enable row level security;

-- 5) Номер автора ставить сама база (його не можна підробити)
create or replace function public.set_author() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.user_id := auth.uid();
  new.author_no := (select public_no from public.profiles where user_id = auth.uid());
  return new;
end $$;
drop trigger if exists posts_set_author on public.posts;
create trigger posts_set_author before insert on public.posts
  for each row execute function public.set_author();
drop trigger if exists comments_set_author on public.comments;
create trigger comments_set_author before insert on public.comments
  for each row execute function public.set_author();

-- 6) 3 скарги -> пост ховається
create or replace function public.hide_reported() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.posts set hidden = true
  where id = new.post_id and (select count(*) from public.reports where post_id = new.post_id) >= 3;
  return new;
end $$;
drop trigger if exists reports_hide on public.reports;
create trigger reports_hide after insert on public.reports
  for each row execute function public.hide_reported();

-- 7) Правила доступу (RLS)
drop policy if exists "posts read" on public.posts;
create policy "posts read" on public.posts for select to authenticated
  using ((visibility = 'public' and not hidden) or user_id = auth.uid() or public.is_admin());
drop policy if exists "posts insert own" on public.posts;
create policy "posts insert own" on public.posts for insert to authenticated
  with check (user_id = auth.uid());
drop policy if exists "posts delete own" on public.posts;
create policy "posts delete own" on public.posts for delete to authenticated
  using (user_id = auth.uid() or public.is_admin());

drop policy if exists "likes read" on public.likes;
create policy "likes read" on public.likes for select to authenticated using (true);
drop policy if exists "likes insert own" on public.likes;
create policy "likes insert own" on public.likes for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.posts p where p.id = post_id));
drop policy if exists "likes delete own" on public.likes;
create policy "likes delete own" on public.likes for delete to authenticated
  using (user_id = auth.uid());

drop policy if exists "comments read" on public.comments;
create policy "comments read" on public.comments for select to authenticated
  using (exists (select 1 from public.posts p where p.id = post_id));
drop policy if exists "comments insert own" on public.comments;
create policy "comments insert own" on public.comments for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.posts p where p.id = post_id));
drop policy if exists "comments delete" on public.comments;
create policy "comments delete" on public.comments for delete to authenticated
  using (user_id = auth.uid() or public.is_admin()
         or exists (select 1 from public.posts p where p.id = post_id and p.user_id = auth.uid()));

drop policy if exists "reports insert own" on public.reports;
create policy "reports insert own" on public.reports for insert to authenticated
  with check (user_id = auth.uid());

-- 8) Сховище фото стрічки (приватне; бачити фото можна лише тоді, коли бачиш сам пост)
insert into storage.buckets (id, name, public) values ('feed', 'feed', false) on conflict (id) do nothing;
drop policy if exists "feed read" on storage.objects;
drop policy if exists "feed insert own" on storage.objects;
drop policy if exists "feed delete" on storage.objects;
create policy "feed read" on storage.objects for select to authenticated
  using (bucket_id = 'feed' and (
    (storage.foldername(name))[1] = auth.uid()::text
    or public.is_admin()
    or exists (select 1 from public.posts p where p.photo_path = name and p.visibility = 'public' and not p.hidden)
  ));
create policy "feed insert own" on storage.objects for insert to authenticated
  with check (bucket_id = 'feed' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "feed delete" on storage.objects for delete to authenticated
  using (bucket_id = 'feed' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

-- Перевірка: має показати 4 таблиці зі словом true в колонці rowsecurity.
select tablename, rowsecurity from pg_tables
where schemaname = 'public' and tablename in ('posts','likes','comments','reports') order by tablename;
