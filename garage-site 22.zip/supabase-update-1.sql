-- Garage: публічні номери акаунтів (GAR-0000001, GAR-0000002 ...) за порядком реєстрації.
-- Вставте весь цей текст у Supabase -> SQL Editor і натисніть Run.

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  public_no bigint generated always as identity unique,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
drop policy if exists "profiles read own" on public.profiles;
create policy "profiles read own" on public.profiles
  for select to authenticated using (auth.uid() = user_id);

-- Акаунти, які вже існують: найстаріший отримає №1.
insert into public.profiles (user_id)
select id from auth.users order by created_at
on conflict (user_id) do nothing;

-- Усі нові акаунти отримують наступний номер автоматично.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (user_id) values (new.id) on conflict (user_id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Перевірка: у результаті має бути ваша пошта з номером 1.
select p.public_no, u.email, u.created_at
from public.profiles p join auth.users u on u.id = p.user_id
order by p.public_no;
